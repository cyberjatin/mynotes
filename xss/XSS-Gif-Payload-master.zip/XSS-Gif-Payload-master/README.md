# XSS-Gif-Payload
A XSS Payload in a gif file


Upload it and it's done :D
